# CustomLevelKB

Customize all your worlds KB and delay hit!

Use /customlevelkb (setkb or setdelay) (amount)

Heres my YouTube channel if you want to check the plugin review: https://www.youtube.com/watch?v=M5Y0KXgAuho&t=18s
